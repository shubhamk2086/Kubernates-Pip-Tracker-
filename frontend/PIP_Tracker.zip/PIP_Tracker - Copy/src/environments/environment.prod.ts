// src/environments/environment.prod.ts
export const environment = {
  production: true,
  apiUrl: '/api',
  appName: 'PIP_Tracker',
  enabledDebug:false
 
};
