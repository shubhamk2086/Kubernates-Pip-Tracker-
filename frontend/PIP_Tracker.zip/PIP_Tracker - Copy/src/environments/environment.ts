
export const environment = {
  production: true,
  apiUrl: '/api' ,
  enabledDebug: false
 
  
};


