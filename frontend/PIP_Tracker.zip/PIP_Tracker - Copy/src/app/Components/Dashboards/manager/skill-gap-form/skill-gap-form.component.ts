import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { EmployeeService } from '../../../../services/employee.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-skill-gap-form',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './skill-gap-form.component.html',
  styleUrls: ['./skill-gap-form.component.css']
})
export class SkillGapFormComponent implements OnInit {
  // auth + context
  token = '';
  managerId = '';

  // ui lists/state
  employees: any[] = [];
  skillGaps: any[] = [];
  isLoading = true;
  isLoadingGaps = false;

  // messages
  errorMessage = '';
  successMessage = '';

  // form fields
  selectedEmployeeId = '';
  requiredSkills = '';
  currentSkills = '';
  gapLevel: number | null = null;
  skill = '';
  suggestedTraining = '';

  constructor(
    private employeeService: EmployeeService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.token = localStorage.getItem('token') || '';

    // read manager from localStorage (user object)
    const userRaw = localStorage.getItem('user');
    if (userRaw) {
      try {
        const user = JSON.parse(userRaw);
        this.managerId = user?.id || '';
      } catch {
        this.managerId = '';
      }
    }

    if (!this.token || !this.managerId) {
      this.errorMessage = 'Authentication token or Manager ID missing. Please log in again.';
      this.isLoading = false;
      return;
    }

    // load team
    this.employeeService.getTeamMembers(this.managerId, this.token).subscribe({
      next: (data) => {
        this.employees = Array.isArray(data) ? data : [];
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error fetching team members', err);
        this.errorMessage = 'Could not load team members!';
        this.isLoading = false;
      }
    });
  }

  onSubmit(): void {
    this.successMessage = '';
    this.errorMessage = '';

    // basic validation
    if (!this.selectedEmployeeId) {
      this.errorMessage = 'Please select an employee.';
      return;
    }
    if (!this.requiredSkills || !this.currentSkills || this.gapLevel === null) {
      this.errorMessage = 'Please fill all required fields.';
      return;
    }

    const payload = {
      employeeId: this.selectedEmployeeId,   // MUST be the actual ID (UUID/number)
      requiredSkills: this.requiredSkills,
      currentSkills: this.currentSkills,
      gapLevel: this.gapLevel,
      skill: this.skill,
      suggestedTraining: this.suggestedTraining
    };

    console.log('📤 Sending Payload:', payload);

    this.employeeService.addSkillGap(payload, this.token).subscribe({
      next: (res) => {
        console.log('✅ Backend response:', res);

        // 🔥 Always show clean success message
        this.successMessage = 'Skill gap submitted successfully!';
        this.errorMessage = '';

        // keep selected employee, clear other fields
        const empId = this.selectedEmployeeId;
        this.resetForm(false);
        this.selectedEmployeeId = empId;
        this.loadSkillGaps(empId);
      },
      error: (err) => {
        console.error('❌ Submission failed:', err);

        if (typeof err?.error === 'string') {
          this.errorMessage = err.error;
        } else if (err?.error?.message) {
          this.errorMessage = err.error.message;
        } else {
          this.errorMessage = 'Failed to submit skill gap.';
        }

        this.successMessage = '';
      }
    });
  }

  loadSkillGaps(empId: string): void {
    if (!empId) return;

    this.isLoadingGaps = true;
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.token}`);

    this.http
      .get<any[]>(`http://localhost:8080/api/skill-gap/employee/${empId}`, { headers })
      .subscribe({
        next: (data) => {
          this.skillGaps = Array.isArray(data) ? data : [];
          this.isLoadingGaps = false;
        },
        error: (err) => {
          console.error('Error fetching skill gaps', err);
          this.errorMessage = 'Failed to load skill gaps.';
          this.isLoadingGaps = false;
        }
      });
  }

  /**
   * Reset form fields.
   * @param clearEmployee whether to also clear employee selection
   */
  resetForm(clearEmployee = true): void {
    if (clearEmployee) this.selectedEmployeeId = '';
    this.requiredSkills = '';
    this.currentSkills = '';
    this.gapLevel = null;
    this.skill = '';
    this.suggestedTraining = '';
  }
}
